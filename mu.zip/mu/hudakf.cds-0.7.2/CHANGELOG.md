# Change Log

## [0.6]
- Clarified that this is ABAP CDS, not CAP CDS

## [0.5]
- Added code snippets based on the ones in ADT
- Changed license
- Added some missing keywords
- Added icon

## [0.4]
- Added asddlxs extension
- Fixed some scope names

## [0.1]

- Initial release