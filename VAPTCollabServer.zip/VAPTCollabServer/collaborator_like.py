#!/usr/bin/env python3
"""
collaborator_like.py
Simple Flask-based "collaborator-like" HTTP capture server.
- Captures any HTTP method on any path
- Stores captures to a SQLite DB
- Small UI to list and view captures
"""

import os
import sqlite3
import json
from datetime import datetime
from flask import Flask, request, g, jsonify, render_template_string, abort

DB_PATH = os.environ.get("COLLAB_DB", "collab.db")
app = Flask(__name__)

# --- DB helpers ---
def get_db():
    db = getattr(g, "_db", None)
    if db is None:
        db = g._db = sqlite3.connect(DB_PATH, check_same_thread=False)
        db.row_factory = sqlite3.Row
    return db

def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS captures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT,
        method TEXT,
        remote_addr TEXT,
        timestamp TEXT,
        headers TEXT,
        query_params TEXT,
        body BLOB,
        form TEXT,
        json_body TEXT
    );
    """)
    db.commit()

@app.teardown_appcontext
def close_db(exception):
    db = getattr(g, "_db", None)
    if db is not None:
        db.close()

# --- capture utility ---
def save_capture(path, method, remote_addr, headers, query_params, body, form, json_body):
    db = get_db()
    db.execute(
        "INSERT INTO captures (path, method, remote_addr, timestamp, headers, query_params, body, form, json_body) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            path,
            method,
            remote_addr,
            datetime.utcnow().isoformat() + "Z",
            json.dumps(dict(headers)),
            json.dumps(dict(query_params)),
            body,
            json.dumps(dict(form)),
            json.dumps(json_body) if json_body is not None else None,
        ),
    )
    db.commit()
    return db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]

# --- UI templates ---
INDEX_HTML = """
<!doctype html>
<title>Collaborator-like Server</title>
<h1>Captured Requests ({{count}})</h1>
<p>To test: curl -X POST http://{{host}}/randompath -d 'hello' -H "X-Test:1"</p>
<table border=1 cellpadding=6>
<tr><th>ID</th><th>When (UTC)</th><th>Method</th><th>Path</th><th>Remote</th><th>View</th></tr>
{% for r in rows %}
<tr>
  <td>{{r['id']}}</td>
  <td>{{r['timestamp']}}</td>
  <td>{{r['method']}}</td>
  <td>{{r['path']}}</td>
  <td>{{r['remote_addr']}}</td>
  <td><a href="/view/{{r['id']}}">view</a></td>
</tr>
{% endfor %}
</table>
"""

VIEW_HTML = """
<!doctype html>
<title>Capture {{row['id']}}</title>
<h1>Capture {{row['id']}}</h1>
<p><a href="/">← back</a></p>
<ul>
  <li><b>When (UTC):</b> {{row['timestamp']}}</li>
  <li><b>Method:</b> {{row['method']}}</li>
  <li><b>Path:</b> {{row['path']}}</li>
  <li><b>Remote:</b> {{row['remote_addr']}}</li>
</ul>
<h2>Headers</h2>
<pre>{{row['headers']}}</pre>
<h2>Query params</h2>
<pre>{{row['query_params']}}</pre>
<h2>Form</h2>
<pre>{{row['form']}}</pre>
<h2>JSON body</h2>
<pre>{{row['json_body']}}</pre>
<h2>Raw body (bytes)</h2>
<pre>{{body_preview}}</pre>
"""

# --- Routes ---
@app.route("/")
def index():
    db = get_db()
    rows = db.execute("SELECT id, timestamp, method, path, remote_addr FROM captures ORDER BY id DESC LIMIT 200").fetchall()
    return render_template_string(INDEX_HTML, rows=rows, count=len(rows), host=request.host)

@app.route("/view/<int:cid>")
def view_capture(cid):
    db = get_db()
    row = db.execute("SELECT * FROM captures WHERE id = ?", (cid,)).fetchone()
    if not row:
        abort(404)
    # present raw body safely (show up to 2000 chars)
    body = row["body"] or b""
    try:
        body_preview = body.decode("utf-8", errors="replace")
    except Exception:
        body_preview = repr(body)
    if len(body_preview) > 2000:
        body_preview = body_preview[:2000] + "\n\n[truncated]"
    return render_template_string(VIEW_HTML, row=row, body_preview=body_preview)

# catch-all for any path and any method
@app.route("/<path:subpath>", methods=["GET","POST","PUT","DELETE","PATCH","OPTIONS","HEAD","TRACE"])
@app.route("/", defaults={"subpath": ""}, methods=["GET","POST","PUT","DELETE","PATCH","OPTIONS","HEAD","TRACE"])
def catch_all(subpath):
    # capture details
    path = "/" + subpath
    method = request.method
    remote = request.remote_addr or request.environ.get("HTTP_X_FORWARDED_FOR", "")
    headers = {k: v for k, v in request.headers.items()}
    query_params = request.args.to_dict(flat=False)
    form = request.form.to_dict(flat=False)
    try:
        json_body = request.get_json(silent=True)
    except Exception:
        json_body = None
    # get raw body bytes
    body_bytes = request.get_data()
    # persist
    cid = save_capture(path, method, remote, headers, query_params, body_bytes, form, json_body)
    # respond in a way collaborator would: show an identifier in body
    resp_body = {
        "message": "Captured",
        "id": cid,
        "path": path,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    return jsonify(resp_body), 200

# simple JSON API to fetch captured items
@app.route("/api/list")
def api_list():
    db = get_db()
    rows = db.execute("SELECT id, timestamp, method, path, remote_addr FROM captures ORDER BY id DESC LIMIT 200").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/get/<int:cid>")
def api_get(cid):
    db = get_db()
    row = db.execute("SELECT * FROM captures WHERE id = ?", (cid,)).fetchone()
    if not row:
        return jsonify({"error":"not found"}), 404
    # convert sqlite row to dict
    d = dict(row)
    # convert blob to base64-safe representation
    body = d.get("body") or b""
    try:
        d["body_text"] = body.decode("utf-8", errors="replace")
    except Exception:
        d["body_text"] = None
    return jsonify(d)

# initialize DB on startup
if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)

